import React from "react";
import NewLoader from "./PageLoader/newLoader";
export default function DataLoader() {
  return (
    <div style={{ position: "relative", padding: "120px 0px" }}>
      <NewLoader />
    </div>
  );
}
